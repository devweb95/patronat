<footer class="main-footer">
    	<div class="container">
        	<!--Widgets Section-->
            <div class="widgets-section">
            	<div class="row clearfix">
                	
                    <!--Column-->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
						
                        	<!--Footer Column-->
                            <div class="footer-column col-lg-7 col-md-6 col-sm-12">
                                <div class="footer-widget logo-widget">
									<div class="logo">
										<a href="#"><img src="{{asset('images/logoheader.png')}}" alt="" /></a>
									</div>
									<div class="text">Porte-voix du secteur privé, le COGEF œuvre pour la représentation, le dialogue public-privé, le renforcement des capacités des entreprises et la promotion d’un environnement économique favorable.</div>
									<!-- <ul class="list-style-three">
										<li><span class="icon fa fa-phone"></span> (+226) 25 33 03 09</li>
										<li><span class="icon fa fa-envelope"></span> contact@patronat.bf</li>
										<li><span class="icon fa fa-home"></span>Av. Kwame Nkrumah, Koulouba, 01 BP 1482 Ouagadougou 01, Ouagadougou, Burkina Faso</li>
									</ul> -->
								</div>
							</div>
							
							<!--Footer Column-->
                            <div class="footer-column col-lg-5 col-md-6 col-sm-12">
                                <div class="footer-widget links-widget">
									<h4>Liens</h4>
									<ul class="list-link">
										<li><a href="">Accueil</a></li>
										<li><a href="">A propos</a></li>
										<li><a href="">Services</a></li>
										<li><a href="">Portfolio</a></li>
										<li><a href="">Articles</a></li>
										<li><a href="">Contactez nous</a></li>
									</ul>
								</div>
							</div>

						</div>
					</div>
					
					<!--Column-->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
						
                        	<!--Footer Column-->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget links-widget">
									<h4>Support</h4>
									<ul class="list-link">
										<!-- <li><a href="">Contact Us</a></li> -->
										<!-- <li><a href="">Submit a Ticket</a></li>
										<li><a href="">Visit Knowledge Base</a></li> -->
										<li><a href="">Support System</a></li>
										<li><a href="">Politiques de confidentialité</a></li>
										<li><a href="">Services Professionel </a></li>
									</ul>
								</div>
							</div>
							
							<!--Footer Column-->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget gallery-widget">
									<h4>Gallerie</h4>
									<div class="widget-content">
										<div class="images-outer clearfix">
											<ul class="list-style-three">
												<li><span class="icon fa fa-phone"></span> (+226) 25 33 03 09</li>
												<li><span class="icon fa fa-envelope"></span> contact@patronat.bf</li>
												<li><span class="icon fa fa-home"></span>Av. Kwame Nkrumah, Koulouba, 01 BP 1482 Ouagadougou 01, Ouagadougou, Burkina Faso</li>
											</ul>
											<!-- 
											<figure class="image-box"><a href="images/gallery/1.jpg" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/gallery/footer-gallery-thumb-1.jpg" alt=""></a></figure>
											
											<figure class="image-box"><a href="images/gallery/2.jpg" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/gallery/footer-gallery-thumb-2.jpg" alt=""></a></figure>
											
											<figure class="image-box"><a href="images/gallery/3.jpg" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/gallery/footer-gallery-thumb-3.jpg" alt=""></a></figure>
											
											<figure class="image-box"><a href="images/gallery/4.jpg" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/gallery/footer-gallery-thumb-4.jpg" alt=""></a></figure>
											
											<figure class="image-box"><a href="images/gallery/5.jpg" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/gallery/footer-gallery-thumb-5.jpg" alt=""></a></figure>
										
											<figure class="image-box"><a href="images/gallery/6.jpg" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="images/gallery/footer-gallery-thumb-6.jpg" alt=""></a></figure> --> 
										</div>
									</div>
								</div>
							</div>
							
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
		<!-- Footer Bottom -->
		<div class="footer-bottom">
			<div class="container">
				<div class="row clearfix">
					
					<!-- Copyright Column -->
					<div class="copyright-column col-lg-6 col-md-6 col-sm-12">
						<div class="copyright">2025 &copy; Tous droits réservés par <a href="https://jofedigital.com/">Jofedigital</a></div>
					</div>
					
					<!-- Social Column -->
					<div class="social-column col-lg-6 col-md-6 col-sm-12">
						<ul>
							<li class="follow">Suivez-nous: </li>
							<li><a href="#"><span class="fa fa-facebook-square"></span></a></li>
							<li><a href="#"><span class="fa fa-twitter-square"></span></a></li>
							<li><a href="#"><span class="fa fa-linkedin-square"></span></a></li>
							<li><a href="#"><span class="fa fa-google-plus-square"></span></a></li>
							<li><a href="#"><span class="fa fa-rss-square"></span></a></li>
						</ul>
					</div>
					
				</div>
			</div>
		</div>
	</footer>